class Calculadora {
    constructor(operadorAnteriorTextElement, operadorAtualTextElement) {
        this.operadorAnteriorTextElement = operadorAtualTextElement
        this.operadorAtualTextElement = operadorAnteriorTextElement
        this.clear()
    }

    clear() {
        this.operadorAtual = ''
        this.operadorAnterior= ''
        this.operacao = undefined
    }

    del() {
        this.operadorAtual = this.operadorAtual.toString().slice(0, -1)
     }

    acrescentarNum(num) {
        if (num === '.' && this.operadorAtual.includes('.')) return
        this.operadorAtual = this.operadorAtual.toString() + num.toString()
    }

    escolherOperacao(operacao) {
        if (this.operadorAtual === '') return
        if (this.operadorAnterior !== ''){
            this.computar()
        }
        this.operacao = operacao
        this.operadorAnterior = this.operadorAtual
        this.operadorAtual = ''
    }

    computar() {
        let computacao
        const anterior = parseFloat(this.operadorAnterior)
        const atual = parseFloat (this.operadorAtual)
        if (isNaN(anterior) || isNaN(atual)) return
        switch (this.operacao){
            case '+':
                computacao = anterior + atual
                break
            case 'x':
                computacao = anterior * atual
                break
            case '-':
                computacao = anterior - atual
                break
            case '÷':
                computacao = anterior / atual
                break
            default:
                return
        }
        this.operadorAtual = computacao
        this.operacao = undefined
        this.operadorAnterior = ''
        }
    
    pegarNumDisplay(num) {
        const numString = num.toString()
        const digitoInteiro = parseFloat(numString.split('.')[0])
        const digitoDecimal = numString.split('.')[1]
        let displayInteiro
        if(isNaN(digitoInteiro)){
            displayInteiro = ''
        } else {
            displayInteiro = digitoInteiro.toLocaleString('en', {
                maximumFractionDigits: 0})
        }

        if (digitoDecimal != null) {
            return `${displayInteiro}.${digitoDecimal}`
        } else {
            return displayInteiro
        }
    }
     
    updateDisplay() {
        this.operadorAtualTextElement.innerText = 
            this.pegarNumDisplay (this.operadorAtual)
        if (this.operacao != null){ 
            this.operadorAnteriorTextElement.innerText = 
                `${this.pegarNumDisplay (this.operadorAnterior)} ${this.operacao}`
        } else {
            this.operadorAnteriorTextElement.innerText = ''
        }
    }
}


const botoesNum = document.querySelectorAll('[data-num]')
const botoesOperacao = document.querySelectorAll('[data-operacao]')
const botaoIgual = document.querySelector('[data-igual]')
const botaoDel = document.querySelector('[data-del]')
const botaoAC = document.querySelector('[data-all-clear]')
const operadorAnteriorTextElement = document.querySelector('[data-operador-anterior]')
const operadorAtualTextElement = document.querySelector('[data-operador-atual]')

const calculadora = new Calculadora(operadorAtualTextElement, operadorAnteriorTextElement)

botoesNum.forEach(button => {
    button.addEventListener('click', () => {
        calculadora.acrescentarNum(button.innerText)
        calculadora.updateDisplay()
    })
})

botoesOperacao.forEach(button => {
    button.addEventListener('click', () => {
        calculadora.escolherOperacao(button.innerText)
        calculadora.updateDisplay()
    })
})

botaoIgual.addEventListener('click', () => {
    calculadora.computar()
    calculadora.updateDisplay()
})

botaoAC.addEventListener('click', () => {
    calculadora.clear()
    calculadora.updateDisplay()
})

botaoDel.addEventListener('click', () => {
    calculadora.del()
    calculadora.updateDisplay()
})